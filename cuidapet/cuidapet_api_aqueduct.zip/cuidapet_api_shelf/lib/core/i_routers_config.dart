import '../cuidapet_api.dart';

abstract class IRoutersConfig {
  void configure(Router router);
}